/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Scott
 */
public class Problem1 {
    
    // Basic Problem:
    /* 
        This problem MUST implement regular arrays (no ArrayList)
        
        Create a method that accepts an integer and returns a String array containing each
        digit in String form. Your array should only contain as many elements as there are digits.
        Ex:   accepts -> 247    returns -> ["two"]["four"]["seven"]    
    */
    
    
    
    // Extension Problem:
    /*
        This problem MUST implement regular arrays (no ArrayList)
    
        Create your own custom integer comparison method called 'inefficientComparer'. 
        It should accept two ints, store the digits in a String array (as in the basic 
	problem), and then compare the arrays to one another one element at
        a time. Return a boolean based on the result of the comparison.
    */
    
    
    
    
    
    
    
}
