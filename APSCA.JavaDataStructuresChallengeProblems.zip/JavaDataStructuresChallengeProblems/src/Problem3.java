/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Scott
 */
public class Problem3 {
    
        // Basic Problem:
    /* 
        **For these problems, you are NOT allowed to use any pre-created sorting
        methods**
    

        Create a method called 'orderedInt' that accepts an Int as a parameter.
        The method should add this int into an ArrayList<Integer> in an
        appropriate position so that all elements in the array list are
        stored from smallest to largest.    
        You may assume the ArrayList<Integer> begins empty.
            
    
    */
    
    
    
        //Extension Problem:
    /*
        Create a method called 'orderedString' that accepts a String as a 
        parameter. The method should add this String into an
        Arraylist<String> in an appropriate position so that all elements
        in the array list are sorted alphabetically.
        You may also assume this list begins empty.
    */
    
}
